<!DOCTYPE html>
<html lang="zxx">
<head>
    <title>About us | Artelligence</title>
    <!-- /SEO Ultimate -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    <meta charset="utf-8">
    <link rel="apple-touch-icon" sizes="57x57" href="assets/images/favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="assets/images/favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="assets/images/favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="assets/images/favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="assets/images/favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="assets/images/favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="assets/images/favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="assets/images/favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/images/favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="assets/images/favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/images/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="assets/images/favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon/favicon-16x16.png">
    <link rel="manifest" href="assets/images/favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <!-- Latest compiled and minified CSS -->
    <link href="assets/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="./assets/js/bootstrap.min.js">
    <!-- Font Awesome link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <!-- StyleSheet link CSS -->
    <link href="assets/css/style.css" rel="stylesheet" type="text/css">
    <link href="assets/css/responsive.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
</head>

<body>
<!--Header  -->
<div class="sub-banner">
    <header class="header">
        <div class="container-fluid">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a class="navbar-brand" href="./index.html"><figure class="mb-0 banner-logo"><img src="./assets/images/logo.png" alt="" class="img-fluid"></figure></a>
                <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" 
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                <span class="navbar-toggler-icon"></span>
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="./index.html">Home</a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="./about.html">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./service.html">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./projects.html">Projects</a>
                        </li>
                        <li class="nav-space nav-item dropdown">
                            <a class="nav-link dropdown-toggle dropdown-color navbar-text-color" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false"> Pages </a>
                            <div class="dropdown-menu drop-down-content">
                                <ul class="list-unstyled drop-down-pages">
                                    <li class="nav-item">
                                        <a class="dropdown-item nav-link" href="./team.html">Teams</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="dropdown-item nav-link" href="./faq.html">Faq's</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-space nav-item">
                            <a class="nav-link" href="./contact.html">Contact us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link lets_talk" href="./contact.html">Let's Talk<i class="circle fa-regular fa-angle-right"></i></a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </header>
    <figure class="sub-bannersideshape mb-0">
        <img src="./assets/images/sub-bannersideshape.png" alt="" class="img-fluid">
    </figure>
<!-- Sub-Banner -->
    <section class="banner-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 col-md-6 col-sm-12 col-12">
                    <div class="banner_content" data-aos="fade-right">
                        <h1 class="text-white">About Us</h1>
                        <p class="text-white">Ruis autem vel eum iure reprehenderit aui in ea voluptate velit esse ruam nihil molestiae conseuatur.</p>
                        <div class="box">
                            <span class="mb-0">Home</span><i class="first fa-regular fa-angle-right"></i><i class="second fa-regular fa-angle-right"></i><span class="mb-0 box_span">About</span>
                        </div> 
                    </div>
                </div> 
                <div class="col-lg-5 col-md-6 col-sm-12 col-12">
                    <div class="banner_wrapper">
                        <figure class="mb-0 sub-bannerimage">
                            <img src="./assets/images/sub-bannerimage.png" alt="" class="">
                        </figure> 
                    </div>  
                </div>
            </div>
        </div> 
        <figure class="sub-bannersideshape2 mb-0">
            <img src="./assets/images/sub-bannersideshape2.png" alt="" class="img-fluid">
        </figure>
    </section>
</div>
<!-- About -->
<section class="aboutpage-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="aboutpage_wrapper">
                    <figure class="mb-0 aboutpage-image">
                        <img src="./assets/images/aboutpage-image.png" alt="" class="">
                    </figure> 
                    <figure class="mb-0 aboutpage-image2">
                        <img src="./assets/images/aboutpage-image2.png" alt="" class="img-fluid">
                    </figure>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="aboutpage_content" data-aos="fade-right">
                    <h5>About us</h5>
                    <h2>Empowering People By Keeping Them Well</h2>
                    <p class="text-size-18">Repellendus autem ruibusdam et aut officiis debitis aut re necessitatibus saepe eveniet ut et voluptates repudianda sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus.</p>
                    <ul class="list-unstyled mb-0">
                        <li class="text text-size-18"><i class="circle fa-regular fa-angle-right"></i>Quis autem vel eum iure reprehenderit aui</li>
                        <li class="text text-size-18"><i class="circle fa-regular fa-angle-right"></i>Suscipit laboriosam nisi rut aliuid eum iure moli</li>
                        <li class="text text1 text-size-18"><i class="circle fa-regular fa-angle-right"></i>Dolor repellendus temporibus autem auibus</li>
                    </ul>
                    <a class="read_more text-decoration-none" href="./about.html">Read More<i class="circle fa-regular fa-angle-right"></i></a>
                </div>
            </div>
        </div>
    </div>  
</section>
<!-- Counter -->
<section class="counter-section position-relative">
    <div class="container">
        <figure class="counter-sideimage mb-0">
            <img src="./assets/images/counter-sideimage.png" class="img-fluid" alt="">
        </figure>
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="counter-box">
                    <figure class="counter-image1">
                        <img src="./assets/images/counter-image1.png" alt="" class="img-fluid">
                    </figure> 
                    <h3 class="mb-0 counter">398</h3>
                    <span class="mb-0 plus">+</span>
                    <span class="mb-0 text1 text-size-16">Completed Projects</span>
                </div>   
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="counter-box">
                    <figure class="counter-image2">
                        <img src="./assets/images/counter-image2.png" alt="" class="img-fluid">
                    </figure> 
                    <h3 class="mb-0 counter">120</h3>
                    <span class="mb-0 plus">+</span>
                    <span class="mb-0 text1 text-size-16">Satisfied  Clients</span>
                </div>   
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="counter-box">
                    <figure class="counter-image3">
                        <img src="./assets/images/counter-image3.png" alt="" class="img-fluid">
                    </figure> 
                    <h3 class="mb-0 counter">86</h3>
                    <span class="mb-0 plus">%</span>
                    <span class="mb-0 text1 text-size-16">Website Analysis</span>
                </div>   
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-6">
                <div class="counter-box">
                    <figure class="counter-image4">
                        <img src="./assets/images/counter-image4.png" alt="" class="img-fluid">
                    </figure> 
                    <h3 class="mb-0 counter">240</h3>
                    <span class="mb-0 plus">+</span>
                    <span class="mb-0 text1 text-size-16">Support Done</span>
                </div>   
            </div>
        </div>
    </div>
</section>
<!-- Info video -->
<div class="videosection" data-aos="fade-up">
    <div class="container">
        <div class="row position-relative">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="position-relative">
                    <a class="popup-vimeo" href="https://video-previews.elements.envatousercontent.com/h264-video-previews/d1c81f1e-849f-4d45-ae57-b61c2f5db34a/25628048.mp4">
                        <figure class="mb-0 vediosession">
                            <img class="thumb img-fluid" style="cursor: pointer" src="./assets/images/image-vediosession.png" alt="">
                        </figure>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<!--FAQ / Need section-->
<section class="faq-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="faq_content" data-aos="fade-right">
                    <h5>faq,s</h5>
                    <h2>Frequently Asked Questions</h2>
                    <div class="faq">
                        <div class="row">
                            <div class="col-12">
                                <div class="accordian-section-inner position-relative">
                                    <div class="accordian-inner">
                                        <div id="accordion1">
                                            <div class="accordion-card">
                                                <div class="card-header" id="headingOne">
                                                    <a href="#" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                                        <h4>Antis unde omnis istye natus error?</h4>
                                                    </a>
                                                </div>
                                                <div id="collapseOne" class="collapse" aria-labelledby="headingOne">
                                                    <div class="card-body">
                                                        <p class="text-size-18 text-left mb-0">Labore et dolore magna aliqua quis ipsum suspendis seultrices gravida risus commo ddolore.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-card">
                                                <div class="card-header" id="headingTwo">
                                                    <a href="#" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                        <h4>Quasi sed architecto beatae vitae?</h4>
                                                    </a>
                                                </div>
                                                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo">
                                                    <div class="card-body">
                                                        <p class="text-size-18 text-left mb-0">Labore et dolore magna aliqua quis ipsum suspendis seultrices gravida risus commo ddolore.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-card">
                                                <div class="card-header" id="headingThree">
                                                    <a href="#" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                                        <h4>Totam rem aperiam earue iesa uate?</h4>
                                                    </a>
                                                </div>
                                                <div id="collapseThree" class="collapse" aria-labelledby="headingThree">
                                                    <div class="card-body">
                                                        <p class="text-size-18 text-left mb-0">Labore et dolore magna aliqua quis ipsum suspendis seultrices gravida risus commo ddolore.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-card">
                                                <div class="card-header" id="headingFour">
                                                    <a href="#" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                                        <h4>Duis lacinia pulvinar turpis lacinia?</h4>
                                                    </a>
                                                </div>
                                                <div id="collapseFour" class="collapse" aria-labelledby="headingFour">
                                                    <div class="card-body">
                                                        <p class="text-size-18 text-left mb-0">Labore et dolore magna aliqua quis ipsum suspendis seultrices gravida risus commo ddolore.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-card faq-mb">
                                                <div class="card-header" id="headingFive">
                                                    <a href="#" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                                        <h4>Integer lobortis sem conseruat seua?</h4>
                                                    </a>
                                                </div>
                                                <div id="collapseFive" class="collapse" aria-labelledby="headingFive">
                                                    <div class="card-body">
                                                        <p class="text-size-18 text-left mb-0">Labore et dolore magna aliqua quis ipsum suspendis seultrices gravida risus commo ddolore.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="need-section">
                    <div class="need_content"> 
                        <h3>Need any Help!</h3>
                        <p class="text-size-16">Eiusmod tempor in  labore et dolore magna aliqua ruis ultrices gravida sit amet.</p>
                        <form id="contactpage" method="POST" action="./contact-form.php">
                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group mb-0">    
                                    <input type="text" class="form_style" placeholder="Your Name:" name="name"> 
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group mb-0">
                                    <input type="email" class="form_style" placeholder="Your Email:" name="emailid">
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group mb-0">
                                    <input type="tel" class="form_style" placeholder="Phone:" name="phone">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class=" form-group mb-0">    
                                    <textarea class="form_style" placeholder="Message" rows="3" name="msg"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="manage-button text-center">
                                <button type="submit" class="submit_now text-decoration-none">Submit Now<i class="circle fa-regular fa-angle-right"></i></button>
                            </div>
                        </form>
                        <figure class="faq-image mb-0">
                            <img src="./assets/images/faq-image.png" alt="" class="img-fluid">
                        </figure>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Footer -->
<section class="footer-section">
    <div class="container">
        <figure class="footer-sideshape mb-0">
            <img src="./assets/images/footer-sideshape.png" alt="" class="img-fluid">
        </figure>
        <div class="middle-portion">
            <div class="row">
                <div class="col-lg-4 col-md-5 col-sm-6 col-12">
                    <a href="./index.html">
                        <figure class="footer-logo">
                            <img src="./assets/images/logo.png" class="img-fluid" alt="">
                        </figure>
                    </a>
                    <p class="text-size-16 footer-text text-white">Ruis aute irure dolor in reprehenderit in volu velit ese ciu nulla pariatur excepteur sint oc aecat curidatat nona...</p>
                    <ul class="list-unstyled mb-0 social-icons">
                        <li class="circle"><a href="#"><i class="fa-brands fa-facebook-f"></i></a></li>
                        <li class="circle"><a href="#"><i class="fa-brands fa-twitter"></i></a></li>
                        <li class="circle"><a href="#"><i class="fa-brands fa-linkedin-in"></i></a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-12 col-12 d-md-block d-none">
                    <div class="links">
                        <h4 class="heading text-white">Useful Links</h4>
                        <ul class="list-unstyled mb-0">
                            <li><i class="fa-solid fa-angle-right"></i><a href="./index.html" class=" text-size-16 text text-decoration-none">Home</a></li>
                            <li><i class="fa-solid fa-angle-right"></i><a href="./about.html" class=" text-size-16 text text-decoration-none">About</a></li>
                            <li><i class="fa-solid fa-angle-right"></i><a href="./service.html" class=" text-size-16 text text-decoration-none">Services</a></li>
                            <li><i class="fa-solid fa-angle-right"></i><a href="./projects.html" class=" text-size-16 text text-decoration-none">Projects</a></li>
                            <li><i class="fa-solid fa-angle-right"></i><a href="./contact.html" class=" text-size-16 text text-decoration-none">Contact us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-2 col-sm-12 col-12 d-lg-block d-none">
                    <div class="links list-pd">
                        <h4 class="heading text-white">Our Services</h4>
                        <ul class="list-unstyled mb-0">
                            <li><i class="fa-solid fa-angle-right"></i><a href="./service.html" class=" text-size-16 text text-decoration-none">Robotic Automation</a></li>
                            <li><i class="fa-solid fa-angle-right"></i><a href="./projects.html" class=" text-size-16 text text-decoration-none">Testimonial</a></li>
                            <li><i class="fa-solid fa-angle-right"></i><a href="./service.html" class=" text-size-16 text text-decoration-none">Predective Analysis</a></li>
                            <li><i class="fa-solid fa-angle-right"></i><a href="./team.html" class=" text-size-16 text text-decoration-none">Our Team</a></li>
                            <li><i class="fa-solid fa-angle-right"></i><a href="./faq.html" class=" text-size-16 text text-decoration-none">Faq</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 col-12 d-sm-block">
                    <div class="icon">
                        <h4 class="heading text-white">Contact us</h4>
                        <ul class="list-unstyled mb-0">
                            <li class="text">
                                <i class="fa fa-phone fa-icon footer-location"></i>
                                <a href="tel:+4733378901" class="mb-0 text text-decoration-none text-size-16">+61 3 8376 6284</a></li>
                            <li class="text">
                                <i class="fa fa-envelope fa-icon footer-location"></i>
                                <a href="mailto:info@repay.com" class="mb-0 text text-decoration-none text-size-16">Info@Artelligence.com</a></li>
                            <li class="text">
                                <i class="fa-solid fa-location-dot footer-location footer-location3"></i>
                                <p class="text-size-16">121 King Street, Melbourne 3000 Australia</p></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div id="fixed-form-container">
            <div class="image">
                <figure class="footer-image mb-0">
                    <img src="./assets/images/footer-image.png" alt="" class="img-fluid">
                </figure>
            </div>
            <div class="body">
                <form id="contactpage1" method="POST" action="./contact-form.php">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Your Name:" name="name"> 
                    </div>
                    <div class="form-group">
                        <input type="email" class="form-control" placeholder="Your Email:" name="emailid">
                    </div>
                    <div class="form-group">
                        <input type="tel" class="form-control" placeholder="Phone:" name="phone">
                    </div>
                    <div class="form-group">
                        <textarea class="form_style" placeholder="Message" rows="3" name="msg"></textarea>
                    </div>
                    <button type="submit" class="submit_now text-decoration-none">Submit Now</button>
                </form>
            </div>
        </div>
        <div class="copyright">
            <div class="row">
                <div class="col-12">
                    <p class="mb-0 text-white">Copyright 2023, Artelligence.com All Rights Reserved.</p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Latest compiled JavaScript -->
<script src="assets/js/jquery-3.6.0.min.js"> </script>
<script src="assets/js/bootstrap.min.js"> </script>
<script src="assets/js/video_link.js"></script>
<script src="./assets/js/video.js"></script>
<script src="assets/js/counter.js"></script>
<script src="assets/js/custom.js"></script>
<script src="assets/js/animation_links.js"></script>
<script src="assets/js/animation.js"></script>
</body>
</html><?php /**PATH C:\0.Drive\Genex Edge Solutions\Client Material\Cloud Education\website\myapp\resources\views/about.blade.php ENDPATH**/ ?>