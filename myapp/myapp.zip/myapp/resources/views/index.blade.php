<!DOCTYPE html>
<html lang="zxx">
<head>
    <title>Home | Artelligence</title>
    <!-- /SEO Ultimate -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0">
    <meta charset="utf-8">
    <link rel="apple-touch-icon" sizes="57x57" href="assets/images/favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="assets/images/favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="assets/images/favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="assets/images/favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="assets/images/favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="assets/images/favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="assets/images/favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="assets/images/favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="assets/images/favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="assets/images/favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/images/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="assets/images/favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon/favicon-16x16.png">
    <link rel="manifest" href="assets/images/favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <!-- Latest compiled and minified CSS -->
    <link href="assets/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="./assets/js/bootstrap.min.js">
    <!-- Font Awesome link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <!-- StyleSheet link CSS -->
    <link href="assets/css/style.css" rel="stylesheet" type="text/css">
    <link href="assets/css/responsive.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.css">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
</head>

<body>
<!--Header  -->
<div class="banner_outer">
    <header class="header">
        <div class="container-fluid">
            <nav class="navbar navbar-expand-lg navbar-light">
                <a class="navbar-brand" href="./index.html"><figure class="mb-0 banner-logo"><img src="./assets/images/logo.png" alt="" class="img-fluid"></figure></a>
                <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" 
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                <span class="navbar-toggler-icon"></span>
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="./index.html">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./about.html">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./service.html">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="./projects.html">Projects</a>
                        </li>
                        <li class="nav-space nav-item dropdown">
                            <a class="nav-link dropdown-toggle dropdown-color navbar-text-color" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true"
                                aria-expanded="false"> Pages </a>
                            <div class="dropdown-menu drop-down-content">
                                <ul class="list-unstyled drop-down-pages">
                                    <li class="nav-item">
                                        <a class="dropdown-item nav-link" href="./team.html">Teams</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="dropdown-item nav-link" href="./faq.html">Faq's</a>
                                    </li>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-space nav-item">
                            <a class="nav-link" href="./contact.html">Contact us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link lets_talk" href="./contact.html">Let's Talk<i class="circle fa-regular fa-angle-right"></i></a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </header>
    <figure class="banner-sideshape mb-0">
        <img src="./assets/images/banner-sideshape.png" alt="" class="img-fluid">
    </figure>
<!-- Banner -->
<section class="banner-section">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-7 col-md-12 col-sm-12 col-12">
                <div class="banner_content">
                    <h1 class="text-white">Bring Force of Artificial Intelligence To Business</h1>
                    <p class="text-white">Quis autem vel eum iure reprehenderit aui in ea voluptate velit esse ruam nihil molestiae conseuatur.</p>
                    <div class="banner-button">
                        <a class="button1 lets_talk text-decoration-none" href="./about.html">Read More<i class="circle fa-regular fa-angle-right"></i></a>
                        <a class="lets_talk text-decoration-none" href="./contact.html">Contact Us<i class="circle fa-regular fa-angle-right"></i></a>   
                    </div> 
                </div>
            </div>
            <div class="col-lg-5 col-md-12 col-sm-12 col-12">
                <div class="banner_wrapper" data-aos="fade-right">
                    <figure class="mb-0 banner-image">
                        <img src="./assets/images/banner-image.png" alt="" class="">
                    </figure> 
                </div>
            </div>
        </div>
    </div>
    <figure class="banner-sideshape2 mb-0">
        <img src="./assets/images/banner-sideshape2.png" alt="" class="img-fluid">
    </figure>   
</section>
</div>
<!-- About us -->
<section class="about-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="about_wrapper">
                    <figure class="mb-0 about-image1">
                        <img src="./assets/images/about-image1.png" alt="" class="img-fluid">
                    </figure> 
                    <figure class="mb-0 about-image2">
                        <img src="./assets/images/about-image2.png" alt="" class="img-fluid">
                    </figure>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="about_content" data-aos="fade-right">
                    <h5>About us</h5>
                    <h2>Empowering People By Keeping Them Well</h2>
                    <p class="text-size-18">Repellendus autem ruibusdam et aut officiis debitis aut re necessitatibus saepe eveniet ut et voluptates repudianda sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus.</p>
                    <div class="about-lowercontent">
                        <div class="image">
                            <figure class="mb-0 icon">
                            <img src="./assets/images/about-customer.png" alt="" class="img-fluid">
                            </figure>
                        </div>
                        <div class="content">
                            <h4>100% Customers Satisfaction</h4>
                            <p class="text-size-18">Amet minim mollit non deserunt ullamco est sit aliua dolor do amet sint.</p>
                        </div>
                        <div class="image">
                            <figure class="mb-0 icon">
                                <img src="./assets/images/about-quality.png" alt="" class="img-fluid">
                            </figure>
                        </div>
                        <div class="content">
                            <h4>Quality Assurance Guarantee</h4>
                            <p class="text-size-18 text">Velit officia consequat duis enim velit mollie assu omnis dolor repellendus.</p>
                        </div>
                    </div>
                    <a class="read_more text-decoration-none" href="./about.html">Read More<i class="circle fa-regular fa-angle-right"></i></a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Services -->
<section class="service-section position-relative">
    <div class="container">
        <figure class="service-image mb-0">
            <img src="./assets/images/service-image.png" class="img-fluid" alt="">
        </figure>
        <div class="row">
            <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="service_content" data-aos="fade-right">
                    <h5>Services we provide</h5>
                    <h2>Our Purpose is To Deliver Excellence in Service and Execution</h2>
                    <p class="text-size-18">Repellendus autem ruibusdam et aut officiis debitis aut re necessitatibus saepe eveniet ut et voluptates repudianda sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus.</p>
                    <a class="read_more text-decoration-none" href="./service.html">Read More<i class="circle fa-regular fa-angle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="service_contentbox">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="service-box box-mb">
                                <figure class="service-reboticon">
                                    <img src="./assets/images/service-reboticon.png" alt="" class="img-fluid">
                                </figure> 
                                <h4>Robotic Automation</h4>
                                <p class="text-size-16 mb-2">Autem vel eum iure reprehea rui in ea volutae velit...</p>
                                <a class="read_more text-decoration-none" href="./service.html">Read More</a>
                            </div>   
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="box-top">
                                <div class="service-box box-mb">
                                    <figure class="service-learningicon">
                                        <img src="./assets/images/service-learningicon.png" alt="" class="img-fluid">
                                    </figure>
                                    <h4>Machine learning</h4>
                                    <p class="text-size-16 mb-2">Butem vel eum iure reprehea rui in ea volutae velit...</p>
                                    <a class="read_more text-decoration-none" href="./service.html">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="service-box">
                                <figure class="service-scienceicon">
                                    <img src="./assets/images/service-scienceicon.png" alt="" class="img-fluid">
                                </figure>
                                <h4>Education & Science</h4>
                                <p class="text-size-16 mb-2">Eutem vel eum iure reprehea rui in ea volutae velit...</p>
                                <a class="read_more text-decoration-none" href="./service.html">Read More</a>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                            <div class="box-top">
                                <div class="service-box">
                                    <figure class="service-analysicon">
                                        <img src="./assets/images/service-analysicon.png" alt="" class="img-fluid">
                                    </figure>
                                    <h4>Predictive Analysis</h4>
                                    <p class="text-size-16 mb-2">Rutem vel eum iure reprehea rui in ea volutae velit...</p>
                                    <a class="read_more text-decoration-none" href="./service.html">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Choose -->
<section class="choose-section">
    <div class="container">
    <figure class="choose-sideshape mb-0">
        <img src="./assets/images/choose-sideshape.png" alt="" class="img-fluid">
    </figure>
        <div class="row">
            <div class="col-lg-6 col-md-12 col-sm-12 col-12 order-lg-1 order-2">
                <div class="choose_wrapper">
                    <figure class="mb-0 choose-image">
                        <img src="./assets/images/choose-image.png" alt="" class="">
                    </figure> 
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-sm-12 col-12 order-lg-2 order-1">
                <div class="choose_content" data-aos="fade-right">
                    <h5>Why Choose Us</h5>
                    <h2 class="text-white">Get Closer Look How Business Develop in AI Data Analysis</h2>
                    <p class="text-white text-size-18">Consectetur adipiscing elit sed do eiusmod tempor in 
                        labore et dolore magna aliqua ruis ipsum suspendisse ultrices gravida sit amet.</p>
                    <ul class="list-unstyled mb-0">
                        <li class="text-white text text-size-18"><i class="circle fa-regular fa-angle-right"></i>Quis autem vel eum iure reprehenderit aui</li>
                        <li class="text-white text text-size-18"><i class="circle fa-regular fa-angle-right"></i>Suscipit laboriosam nisi rut aliuid eum iure moli</li>
                        <li class="text-white text text1 text-size-18"><i class="circle fa-regular fa-angle-right"></i>Dolor repellendus temporibus autem auibus</li>
                    </ul>
                    <a class="read_more text-decoration-none" href="./about.html">Read More<i class="circle fa-regular fa-angle-right"></i></a>
                </div>
            </div>
        </div>
    </div>
    <figure class="choose-sideshape2 mb-0">
        <img src="./assets/images/choose-sideshape2.png" alt="" class="img-fluid">
    </figure>   
</section>
<!-- Case Study -->
<section class="study-section">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="study_content">
                    <h5>Case Study</h5>
                    <h2>Explore Our Case Studies</h2>
                </div>
            </div>
        </div>
        <div class="row" data-aos="fade-up">
            <div class="col-lg-4 col-md-4 col-sm-6 col-12">
                <div class="case-box overlay">
                    <figure class="image mb-0">
                        <img src="./assets/images/case-image1.png" alt="" class="img-fluid">
                    </figure>
                    <div class="content">
                        <span class="text-white">Robot Technology</span>
                        <h4 class="text-white">Officia deserunt mollitia animi nobis</h4>
                        <i class="circle fa-regular fa-angle-right"></i>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6 col-12">
                <div class="case-box overlay">
                    <figure class="image mb-0">
                        <img src="./assets/images/case-image2.png" alt="" class="img-fluid">
                    </figure>
                    <div class="content">
                        <span class="text-white">User Research</span>
                        <h4 class="text-white">Eum iure reprehenderit velit esse</h4>
                        <i class="circle fa-regular fa-angle-right"></i>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-6 col-12">
                <div class="case-box overlay">
                    <figure class="image mb-0">
                        <img src="./assets/images/case-image3.png" alt="" class="img-fluid">
                    </figure>
                    <div class="content">
                        <span class="text-white">Machine Learning</span>
                        <h4 class="text-white">Duis aute irure dolor in reprehenderit</h4>
                        <i class="circle fa-regular fa-angle-right"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="lower-images" data-aos="fade-up">
            <div class="row">
                <div class="col-lg-4 col-md-4 col-sm-6 col-12">
                    <div class="case-box overlay">
                        <figure class="image mb-0">
                            <img src="./assets/images/case-image4.png" alt="" class="img-fluid">
                        </figure>
                        <div class="content">
                            <span class="text-white">Data Science</span>
                            <h4 class="text-white">Numruam eius modi tema incidunt labore </h4>
                            <i class="circle fa-regular fa-angle-right"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-12">
                    <div class="case-box overlay">
                        <figure class="image mb-0">
                            <img src="./assets/images/case-image5.png" alt="" class="img-fluid">
                        </figure>
                        <div class="content text-pd">
                            <span class="text-white">Artificial Intelligence</span>
                            <h4 class="text-white">Molestiae non recusana delectuse</h4>
                            <i class="circle fa-regular fa-angle-right"></i>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-12">
                    <div class="case-box overlay">
                        <figure class="image mb-0">
                            <img src="./assets/images/case-image6.png" alt="" class="img-fluid">
                        </figure>
                        <div class="content">
                            <span class="text-white">BI execution</span>
                            <h4 class="text-white">Exercitation ullamco laboris nisa</h4>
                            <i class="circle fa-regular fa-angle-right"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="button">
            <a class="view_all text-decoration-none" href="./about.html">View All<i class="circle fa-regular fa-angle-right"></i></a>
        </div>
    </div>
</section>
<!-- Testimonial -->
<section class="testimonial-section">
    <div class="container">
        <div class="row position-relative">
            <div class="col-12">
                <div class="heading">
                    <h5>Testimonials</h5>
                    <h2>Hear it From Our Clients</h2>
                </div>
                <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <div class="testimonial_content">
                                <div class="content-box">
                                    <p class="h4">“Quisquam est, qui dolorem ipsum quia dolor sit amet conse aetur, adipisci velit, sed ruia non numquam eius modi temor
                                        incidunt ut labore et dolore magnam alieuam zuaerat voluta tem nostrum exercitationem”</p>
                                    <figure class="testimonial-image mb-0">
                                        <img src="./assets/images/testimonial-image.png" alt="" class="img-fluid">
                                    </figure>
                                    <span class="text-size-18">Peter Johns</span>
                                    <span class="text-size-16 mb-0">Head of informatics at EBI</span>
                                    <div class="box">
                                        <figure class="testimonial-comas mb-0">
                                            <img src="./assets/images/testimonial-comas.png" alt="" class="img-fluid">
                                        </figure>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="testimonial_content">
                                <div class="content-box">
                                    <p>“Quisquam est, qui dolorem ipsum quia dolor sit amet conse aetur, adipisci velit, sed ruia non numquam eius modi temor
                                        incidunt ut labore et dolore magnam alieuam zuaerat voluta tem nostrum exercitationem”</p>
                                    <figure class="testimonial-image mb-0">
                                        <img src="./assets/images/testimonial-image.png" alt="" class="img-fluid">
                                    </figure>
                                    <span class="text-size-18">Peter Johns</span>
                                    <span class="text-size-16 mb-0">Head of informatics at EBI</span>
                                    <div class="box">
                                        <figure class="testimonial-comas">
                                            <img src="./assets/images/testimonial-comas.png" alt="" class="img-fluid">
                                        </figure>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="pagination-outer">
                        <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                            <i class="fa-solid fa-angle-right"></i>
                            <span class="sr-only">Next</span>
                        </a>
                        <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                            <i class="fa-solid fa-angle-left"></i>
                            <span class="sr-only">Previous</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <figure class="mb-0 testimonial-sideimage">
            <img src="./assets/images/testimonial-sideimage.png" alt="" class="img-fluid">
        </figure>
    </div>
    <!-- Partner -->
    <div class="partner-section"> 
        <div class="container">
            <div class="partner" data-aos="fade-up">
                <ul class="mb-0 list-unstyled">
                    <li>
                        <figure class="mb-0 partner1 img1">
                            <img class="img-fluid" src="./assets/images/partner1.png" alt="">
                        </figure>
                    </li>
                    <li>
                        <figure class="mb-0 partner1 partner2 img2">
                            <img class="img-fluid" src="./assets/images/partner2.png" alt="">
                        </figure>
                    </li>
                    <li class="img-mb">
                        <figure class="mb-0 partner1 partner3 img3">
                            <img class="img-fluid" src="./assets/images/partner3.png" alt="">
                        </figure>
                    </li>
                    <li>
                        <figure class="mb-0 partner1 partner4 img4">
                            <img class="img-fluid" src="./assets/images/partner4.png" alt="">
                        </figure>
                    </li>
                    <li>
                        <figure class="mb-0 partner1 partner5 img5">
                            <img class="img-fluid" src="./assets/images/partner5.png" alt="">
                        </figure>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>
<!--FAQ / Need section-->
<section class="faq-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="faq_content" data-aos="fade-right">
                    <h5>faq,s</h5>
                    <h2>Frequently Asked Questions</h2>
                    <div class="faq">
                        <div class="row">
                            <div class="col-12">
                                <div class="accordian-section-inner position-relative">
                                    <div class="accordian-inner">
                                        <div id="accordion1">
                                            <div class="accordion-card">
                                                <div class="card-header" id="headingOne">
                                                    <a href="#" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                                                        <h4>Antis unde omnis istye natus error?</h4>
                                                    </a>
                                                </div>
                                                <div id="collapseOne" class="collapse" aria-labelledby="headingOne">
                                                    <div class="card-body">
                                                        <p class="text-size-18 text-left mb-0">Labore et dolore magna aliqua quis ipsum suspendis seultrices gravida risus commo ddolore.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-card">
                                                <div class="card-header" id="headingTwo">
                                                    <a href="#" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                                        <h4>Quasi sed architecto beatae vitae?</h4>
                                                    </a>
                                                </div>
                                                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo">
                                                    <div class="card-body">
                                                        <p class="text-size-18 text-left mb-0">Labore et dolore magna aliqua quis ipsum suspendis seultrices gravida risus commo ddolore.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-card">
                                                <div class="card-header" id="headingThree">
                                                    <a href="#" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                                        <h4>Totam rem aperiam earue iesa uate?</h4>
                                                    </a>
                                                </div>
                                                <div id="collapseThree" class="collapse" aria-labelledby="headingThree">
                                                    <div class="card-body">
                                                        <p class="text-size-18 text-left mb-0">Labore et dolore magna aliqua quis ipsum suspendis seultrices gravida risus commo ddolore.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-card">
                                                <div class="card-header" id="headingFour">
                                                    <a href="#" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                                        <h4>Duis lacinia pulvinar turpis lacinia?</h4>
                                                    </a>
                                                </div>
                                                <div id="collapseFour" class="collapse" aria-labelledby="headingFour">
                                                    <div class="card-body">
                                                        <p class="text-size-18 text-left mb-0">Labore et dolore magna aliqua quis ipsum suspendis seultrices gravida risus commo ddolore.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="accordion-card faq-mb">
                                                <div class="card-header" id="headingFive">
                                                    <a href="#" class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                                        <h4>Integer lobortis sem conseruat seua?</h4>
                                                    </a>
                                                </div>
                                                <div id="collapseFive" class="collapse" aria-labelledby="headingFive">
                                                    <div class="card-body">
                                                        <p class="text-size-18 text-left mb-0">Labore et dolore magna aliqua quis ipsum suspendis seultrices gravida risus commo ddolore.</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="need-section">
                    <div class="need_content"> 
                        <h3>Need any Help!</h3>
                        <p class="text-size-16">Eiusmod tempor in  labore et dolore magna aliqua ruis ultrices gravida sit amet.</p>
                        <form id="contactpage" method="POST" action="./contact-form.php">
                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group mb-0">    
                                        <input type="text" class="form_style" placeholder="Your Name:" name="name"> 
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group mb-0">
                                        <input type="email" class="form_style" placeholder="Your Email:" name="emailid">
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group mb-0">
                                        <input type="tel" class="form_style" placeholder="Phone:" name="phone">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class=" form-group mb-0">    
                                        <textarea class="form_style" placeholder="Message" rows="3" name="msg"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="manage-button text-center">
                                <button type="submit" class="submit_now text-decoration-none">Submit Now<i class="circle fa-regular fa-angle-right"></i></button>
                            </div>
                        </form>
                        <figure class="faq-image mb-0">
                            <img src="./assets/images/faq-image.png" alt="" class="img-fluid">
                        </figure>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Footer -->
<section class="footer-section">
    <div class="container">
        <figure class="footer-sideshape mb-0">
            <img src="./assets/images/footer-sideshape.png" alt="" class="img-fluid">
        </figure>
        <div class="middle-portion">
            <div class="row">
                <div class="col-lg-4 col-md-5 col-sm-6 col-12">
                    <a href="./index.html">
                        <figure class="footer-logo">
                            <img src="./assets/images/logo.png" class="img-fluid" alt="">
                        </figure>
                    </a>
                    <p class="text-size-16 footer-text text-white">Ruis aute irure dolor in reprehenderit in volu velit ese ciu nulla pariatur excepteur sint oc aecat curidatat nona...</p>
                    <ul class="list-unstyled mb-0 social-icons">
                        <li class="circle"><a href="#"><i class="fa-brands fa-facebook-f"></i></a></li>
                        <li class="circle"><a href="#"><i class="fa-brands fa-twitter"></i></a></li>
                        <li class="circle"><a href="#"><i class="fa-brands fa-linkedin-in"></i></a></li>
                    </ul>
                </div>
                <div class="col-lg-2 col-md-3 col-sm-12 col-12 d-md-block d-none">
                    <div class="links">
                        <h4 class="heading text-white">Useful Links</h4>
                        <ul class="list-unstyled mb-0">
                            <li><i class="fa-solid fa-angle-right"></i><a href="./index.html" class=" text-size-16 text text-decoration-none">Home</a></li>
                            <li><i class="fa-solid fa-angle-right"></i><a href="./about.html" class=" text-size-16 text text-decoration-none">About</a></li>
                            <li><i class="fa-solid fa-angle-right"></i><a href="./service.html" class=" text-size-16 text text-decoration-none">Services</a></li>
                            <li><i class="fa-solid fa-angle-right"></i><a href="./projects.html" class=" text-size-16 text text-decoration-none">Projects</a></li>
                            <li><i class="fa-solid fa-angle-right"></i><a href="./contact.html" class=" text-size-16 text text-decoration-none">Contact us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-2 col-sm-12 col-12 d-lg-block d-none">
                    <div class="links list-pd">
                        <h4 class="heading text-white">Our Services</h4>
                        <ul class="list-unstyled mb-0">
                            <li><i class="fa-solid fa-angle-right"></i><a href="./service.html" class=" text-size-16 text text-decoration-none">Robotic Automation</a></li>
                            <li><i class="fa-solid fa-angle-right"></i><a href="./projects.html" class=" text-size-16 text text-decoration-none">Testimonial</a></li>
                            <li><i class="fa-solid fa-angle-right"></i><a href="./service.html" class=" text-size-16 text text-decoration-none">Predective Analysis</a></li>
                            <li><i class="fa-solid fa-angle-right"></i><a href="./team.html" class=" text-size-16 text text-decoration-none">Our Team</a></li>
                            <li><i class="fa-solid fa-angle-right"></i><a href="./faq.html" class=" text-size-16 text text-decoration-none">Faq</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 col-12 d-sm-block">
                    <div class="icon">
                        <h4 class="heading text-white">Contact us</h4>
                        <ul class="list-unstyled mb-0">
                            <li class="text">
                                <i class="fa fa-phone fa-icon footer-location"></i>
                                <a href="tel:+4733378901" class="mb-0 text text-decoration-none text-size-16">+61 3 8376 6284</a></li>
                            <li class="text">
                                <i class="fa fa-envelope fa-icon footer-location"></i>
                                <a href="mailto:info@repay.com" class="mb-0 text text-decoration-none text-size-16">Info@Artelligence.com</a></li>
                            <li class="text">
                                <i class="fa-solid fa-location-dot footer-location footer-location3"></i>
                                <p class="text-size-16">121 King Street, Melbourne 3000 Australia</p></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div id="fixed-form-container">
            <div class="image">
                <figure class="footer-image mb-0">
                    <img src="./assets/images/footer-image.png" alt="" class="img-fluid">
                </figure>
            </div>
            <div class="body">
                <form id="contactpage1" method="POST" action="./contact-form.php">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Your Name:" name="name"> 
                    </div>
                    <div class="form-group">
                        <input type="email" class="form-control" placeholder="Your Email:" name="emailid">
                    </div>
                    <div class="form-group">
                        <input type="tel" class="form-control" placeholder="Phone:" name="phone">
                    </div>
                    <div class="form-group">
                        <textarea class="form_style" placeholder="Message" rows="3" name="msg"></textarea>
                    </div>
                    <button type="submit" class="submit_now text-decoration-none">Submit Now</button>
                </form>
            </div>
        </div>
        <div class="copyright">
            <div class="row">
                <div class="col-12">
                    <p class="mb-0 text-white">Copyright 2023, Artelligence.com All Rights Reserved.</p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Latest compiled JavaScript -->
<script src="assets/js/jquery-3.6.0.min.js"> </script>
<script src="assets/js/bootstrap.min.js"> </script>
<script src="assets/js/video_link.js"></script>
<script src="./assets/js/video.js"></script>
<script src="assets/js/counter.js"></script>
<script src="assets/js/custom.js"></script>
<script src="assets/js/animation_links.js"></script>
<script src="assets/js/animation.js"></script>
</body>
</html>